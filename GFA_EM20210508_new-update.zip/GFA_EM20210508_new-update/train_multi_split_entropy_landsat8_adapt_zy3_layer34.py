import argparse
import os
import sys
import random
import timeit


import cv2
import numpy as np
import pickle
import scipy.misc

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
from torch.utils import data, model_zoo
from torch.autograd import Variable
import torchvision.transforms as transform

from deeplabv2 import Multi_Split_Res_Deeplab, Split_Res_Deeplab, Split_Res_Deeplab_layer3
#from model.deeplabv3p import Res_Deeplab 

from discriminator import s4GAN_discriminator, s4GAN_feature_discriminator, entropy_discriminator, Split_feature_discriminator_0
from loss import CrossEntropy2d
from data.voc_dataset import VOCDataSet, VOCDataSet_unlabel, VOCGTDataSet,  LandDataSet
from data import get_loader, get_data_path
from data.augmentations import *

start = timeit.default_timer()


# load landast8 data

LAND_DATA_DIR = './train_datasets/landsat_8/'
DATA_LIST_PATH = './train_datasets/landsat_8/train_landsat8.txt'

# load zy3 data
GF_DATA_DIR = './train_datasets/zy_3/'
#DATA_LIST_PATH2 = './train_datasets/train_zy3.txt'
DATA_LIST_PATH3 = './train_datasets/zy_3/train_zy3_uda.txt'


LAYER_NAME= 'layer3'
CHECKPOINT_DIR = './checkpoints_zy3_adapt/voc_multi_split_entropy_layer34_s0.001_e0.01/'

#checkpoints_advent_feature/voc_advent_feature_landsat_layer3



THRESHOLD_VALUE= 0.55
GPU_NUMBER=0
os.environ['CUDA_VISIBLE_DEVICES']='1'


#Our data type is UINT8,if you data type is 0-1, you should change when subtracting the mean value.
IMG_MEAN = np.array((85.27698793,85.21876762,85.17891434), dtype=np.float32) # zy3
IMG_MEAN2 = np.array((69.44698793,51.68876762,49.67891434), dtype=np.float32) # landsat




NUM_CLASSES = 2 # 21 for PASCAL-VOC / 60 for PASCAL-Context / 19 Cityscapes 
DATASET = 'pascal_voc' #pascal_voc or pascal_context 

SPLIT_ID = './splits/voc/split_0.pkl'

MODEL = 'DeepLab'
BATCH_SIZE = 4
NUM_STEPS = 60000
SAVE_PRED_EVERY = 5000

INPUT_SIZE = '321,321'
IGNORE_LABEL = 255 # 255 for PASCAL-VOC / -1 for PASCAL-Context / 250 for Cityscapes

RESTORE_FROM = '/home/lab532/Remote_sensing/Unsupervised_SemSeg_master/pretrained_models/resnet101-5d3b4d8f.pth'

LEARNING_RATE = 2.5e-4
LEARNING_RATE_D = 1e-4

POWER = 0.9
WEIGHT_DECAY = 0.0005
MOMENTUM = 0.9
NUM_WORKERS = 4
RANDOM_SEED = 1234

LAMBDA_ST = 1.0
LAMBDA_FM = 0.5
LAMBDA_CE = 0.5
LAMBDA_ADAPT = 0.001
LAMBDA_ENTROPY = 0.01


#LAMBDA_ADAPT = 1.0

THRESHOLD_ST = 0.6 # 0.6 for PASCAL-VOC/Context / 0.7 for Cityscapes

LABELED_RATIO = None  #0.02 # 1/8 labeled data by default




def get_arguments():
    """Parse all the arguments provided from the CLI.

    Returns:
      A list of parsed arguments.
    """
    parser = argparse.ArgumentParser(description="DeepLab-ResNet Network")
    parser.add_argument("--gpu", type=int, default=GPU_NUMBER,
                        help="choose gpu device.")	
    parser.add_argument("--data-list", type=str, default=DATA_LIST_PATH,
                        help="Path to the LANDSAT-8 file listing the images in the dataset.")					
    # parser.add_argument("--data-list2", type=str, default=DATA_LIST_PATH2,
                        # help="Path to the gf1 file listing the images in the dataset.")		
    parser.add_argument("--data-list3", type=str, default=DATA_LIST_PATH3,
                        help="Path to the gf1 file listing the images in the dataset.")
						
    parser.add_argument("--checkpoint-dir", type=str, default=CHECKPOINT_DIR,
                        help="Where to save checkpoints of the model.")
				
    parser.add_argument("--model", type=str, default=MODEL,
                        help="available options : DeepLab/DRN")
    parser.add_argument("--dataset", type=str, default=DATASET,
                        help="dataset to be used")
    parser.add_argument("--layer_name", type=str, default=LAYER_NAME,
                        help="layer_name to be used")
						
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE,
                        help="Number of images sent to the network in one step.")
    parser.add_argument("--num-workers", type=int, default=NUM_WORKERS,
                        help="number of workers for multithread dataloading.")
    parser.add_argument("--gf-data-dir", type=str, default=GF_DATA_DIR,
                        help="Path to the directory containing the GF1 dataset.")
    parser.add_argument("--land-data-dir", type=str, default=LAND_DATA_DIR,
                        help="Path to the directory containing the LANDSAT-8 dataset.")
						
    parser.add_argument("--labeled-ratio", type=float, default=LABELED_RATIO,
                        help="ratio of the labeled data to full dataset")
    parser.add_argument("--split-id", type=str, default=SPLIT_ID,
                        help="split order id")
    parser.add_argument("--input-size", type=str, default=INPUT_SIZE,
                        help="Comma-separated string with height and width of images.")
    parser.add_argument("--learning-rate", type=float, default=LEARNING_RATE,
                        help="Base learning rate for training with polynomial decay.")
    parser.add_argument("--learning-rate-D", type=float, default=LEARNING_RATE_D,
                        help="Base learning rate for discriminator.")
    parser.add_argument("--lambda-fm", type=float, default=LAMBDA_FM,
                        help="lambda_fm for feature-matching loss.")
    parser.add_argument("--lambda-st", type=float, default=LAMBDA_ST,
                        help="lambda_st for self-training.")
    parser.add_argument("--lambda-adapt", type=float, default=LAMBDA_ADAPT,
                        help="lambda_adapt for self-training.")
    parser.add_argument("--lambda-ce", type=float, default=LAMBDA_CE,
                        help="lambda_adapt for self-training.")						
    parser.add_argument("--lambda-entropy", type=float, default=LAMBDA_ENTROPY,
                        help="lambda_entropy for entropy loss.")		  

                        
    parser.add_argument("--threshold-st", type=float, default=THRESHOLD_ST,
                        help="threshold_st for the self-training threshold.")
    parser.add_argument("--threshold-value", type=float, default=THRESHOLD_VALUE,
                        help="threshold_value for the self-training threshold.")						
						
    parser.add_argument("--momentum", type=float, default=MOMENTUM,
                        help="Momentum component of the optimiser.")
    parser.add_argument("--ignore-label", type=float, default=IGNORE_LABEL,
                        help="label value to ignored for loss calculation")
    parser.add_argument("--num-classes", type=int, default=NUM_CLASSES,
                        help="Number of classes to predict (including background).")
    parser.add_argument("--num-steps", type=int, default=NUM_STEPS,
                        help="Number of iterations.")
    parser.add_argument("--power", type=float, default=POWER,
                        help="Decay parameter to compute the learning rate.")
    parser.add_argument("--random-mirror", action="store_true",
                        help="Whether to randomly mirror the inputs during the training.")
    parser.add_argument("--random-scale", action="store_true",
                        help="Whether to randomly scale the inputs during the training.")
    parser.add_argument("--random-seed", type=int, default=RANDOM_SEED,
                        help="Random seed to have reproducible results.")
    parser.add_argument("--restore-from", type=str, default=RESTORE_FROM,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D", type=str, default=None,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D1", type=str, default=None,
                        help="Where restore model parameters from.")	
    parser.add_argument("--restore-from-D2", type=str, default=None,
                        help="Where restore model parameters from.")	
						
    parser.add_argument("--restore-from-D31", type=str, default=None,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D32", type=str, default=None,
                        help="Where restore model parameters from.")	
    parser.add_argument("--restore-from-D33", type=str, default=None,
                        help="Where restore model parameters from.")		
    parser.add_argument("--restore-from-D34", type=str, default=None,
                        help="Where restore model parameters from.")		

    parser.add_argument("--restore-from-D41", type=str, default=None,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D42", type=str, default=None,
                        help="Where restore model parameters from.")	
    parser.add_argument("--restore-from-D43", type=str, default=None,
                        help="Where restore model parameters from.")		
    parser.add_argument("--restore-from-D44", type=str, default=None,
                        help="Where restore model parameters from.")	
						
    parser.add_argument("--save-pred-every", type=int, default=SAVE_PRED_EVERY,
                        help="Save summaries and checkpoint every often.")

    parser.add_argument("--weight-decay", type=float, default=WEIGHT_DECAY,
                        help="Regularisation parameter for L2-loss.")

    return parser.parse_args()

args = get_arguments()

def loss_calc(pred, label):
    # label = Variable(label.long()).cuda(args.gpu)
    # criterion = CrossEntropy2d(ignore_label=args.ignore_label).cuda(args.gpu)  # Ignore label ??
    label = Variable(label.long()).cuda()
    criterion = CrossEntropy2d(ignore_label=args.ignore_label).cuda()  # Ignore label ??
    return criterion(pred, label)

def lr_poly(base_lr, iter, max_iter, power):
    return base_lr*((1-float(iter)/max_iter)**(power))

def adjust_learning_rate(optimizer, i_iter):
    lr = lr_poly(args.learning_rate, i_iter, args.num_steps, args.power)
    optimizer.param_groups[0]['lr'] = lr
    if len(optimizer.param_groups) > 1 :
        optimizer.param_groups[1]['lr'] = lr * 10

def adjust_learning_rate_D(optimizer, i_iter):
    lr = lr_poly(args.learning_rate_D, i_iter, args.num_steps, args.power)
    optimizer.param_groups[0]['lr'] = lr
    if len(optimizer.param_groups) > 1 :
        optimizer.param_groups[1]['lr'] = lr * 10

def one_hot(label):
    label = label.numpy()  # N,H,W
    one_hot = np.zeros((label.shape[0], args.num_classes, label.shape[1], label.shape[2]), dtype=label.dtype)  # N,C,H,W
    for i in range(args.num_classes):
        one_hot[:,i,...] = (label==i)
    #handle ignore labels
    return torch.FloatTensor(one_hot)

def compute_argmax_map(output):
    output = output.detach().cpu().numpy() #  c,H,W
    output = output.transpose((1,2,0))  # H,W,c
    output = np.asarray(np.argmax(output, axis=2), dtype=np.int) # H,W; obtain the index thatrepresented the max value through the axis==2 (i.e., channel)
    output = torch.from_numpy(output).float()  # numpy-->torch-->torch float 
    return output
     
def find_good_maps(D_outs, pred_all):
    count = 0
    for i in range(D_outs.size(0)):  # N,C
        if D_outs[i] > args.threshold_st:
            count +=1

    if count > 0:
        #print ('Above ST-Threshold : ', count, '/', args.batch_size)
        pred_sel = torch.Tensor(count, pred_all.size(1), pred_all.size(2), pred_all.size(3)) # n,c,h,w
        label_sel = torch.Tensor(count, pred_sel.size(2), pred_sel.size(3)) # n,h,w
        num_sel = 0 
        for j in range(D_outs.size(0)):
            if D_outs[j] > args.threshold_st:
                pred_sel[num_sel] = pred_all[j]  # get the pred_all[*] map large than threshold value 
                label_sel[num_sel] = compute_argmax_map(pred_all[j]) # score map --> label map with channel==1

                num_sel +=1
        #return  pred_sel.cuda(args.gpu), label_sel.cuda(args.gpu), count  
        return  pred_sel.cuda(), label_sel.cuda(), count  		
    else:
        return 0, 0, count 

		
def compute_ignore_mask(pred0, max_pred):
    pred0 = pred0.detach() # c,H,W    
    pred = torch.chunk(torch.squeeze(pred0,0),2,dim=0)
    pred_1 = torch.squeeze(pred[0],0)	# 1,h,w-->h,w
    pred_1 = pred_1.cpu().numpy() 
    pred_1[pred_1 > args.threshold_value] = 0
    pred_1[pred_1 < 1-args.threshold_value] = 0
    pred_1[pred_1 > 0] = 255    #h,w
    max_pred = max_pred.cpu().numpy() 	
    mask = 	max_pred + pred_1
    mask[mask > 2] = 255  	
    mask =torch.from_numpy(mask) #h,w
    
    return mask	


def find_good_maps_new(D_outs, pred_all, pred_all_2):
    count = 0
    for i in range(D_outs.size(0)):  # N,C
        if D_outs[i] > args.threshold_st:
            count +=1

    if count > 0:
        #print ('Above ST-Threshold : ', count, '/', args.batch_size)
        pred_sel = torch.Tensor(count, pred_all.size(1), pred_all.size(2), pred_all.size(3)) # n,c,h,w
        label_sel = torch.Tensor(count, pred_sel.size(2), pred_sel.size(3)) # n,h,w
        num_sel = 0 
        for j in range(D_outs.size(0)):
            if D_outs[j] > args.threshold_st:
                pred_sel[num_sel] = pred_all[j]  # c,h,w; get the pred_all[*] map large than threshold value 
                #label_sel[num_sel] = compute_argmax_map(pred_all[j]) # H,W; score map --> label map with channel==1
                label_sel[num_sel] = compute_ignore_mask( pred_all_2[j], compute_argmax_map(pred_all[j]) )
                num_sel +=1
        #return  pred_sel.cuda(args.gpu), label_sel.cuda(args.gpu), count  
        return  pred_sel.cuda(), label_sel.cuda(), count  		
    else:
        return 0, 0, count 
        
				
def bce_loss(y_pred, y_label):
    y_truth_tensor = torch.FloatTensor(y_pred.size())
    y_truth_tensor.fill_(y_label)
    y_truth_tensor = y_truth_tensor.to(y_pred.get_device())
    return nn.BCEWithLogitsLoss()(y_pred, y_truth_tensor)
    
def prob_2_entropy(prob):
    """ convert probabilistic prediction maps to weighted self-information maps
    """
    n, c, h, w = prob.size()
    return -torch.mul(prob, torch.log2(prob + 1e-30)) / np.log2(c)    



criterion = nn.BCELoss()

def main():
    print (args)

    h, w = map(int, args.input_size.split(','))
    input_size = (h, w)

    cudnn.enabled = True
    #gpu = args.gpu

    # create network
    model = Multi_Split_Res_Deeplab(num_classes=args.num_classes)
	
    # if args.layer_name == 'layer1':
        # model = Split_Res_Deeplab(num_classes=args.num_classes)
    # elif args.layer_name == 'layer2':
        # model = Split_Res_Deeplab(num_classes=args.num_classes)	
    # elif args.layer_name == 'layer3':
        # model = Split_Res_Deeplab_layer3(num_classes=args.num_classes)	
    # elif args.layer_name == 'layer4':	
        # model = Split_Res_Deeplab(num_classes=args.num_classes)	
    
    # load pretrained parameters
    saved_state_dict = torch.load(args.restore_from)
    new_params = model.state_dict().copy()
    for name, param in new_params.items():
        if name in saved_state_dict and param.size() == saved_state_dict[name].size():
            new_params[name].copy_(saved_state_dict[name])
    model.load_state_dict(new_params)
	
    #model.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000.pth'))	
	
    model.train()
    #model.cuda(args.gpu)
    model.cuda()
    cudnn.benchmark = True

    # init D
    model_D = s4GAN_discriminator(num_classes=args.num_classes, dataset=args.dataset)
    if args.restore_from_D is not None:
        model_D.load_state_dict(torch.load(args.restore_from_D))
    #model_D.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D.pth'))	
    model_D.train()
    model_D.cuda()
	
    # init D1	
    model_D1 = entropy_discriminator(num_classes=args.num_classes,)
    if args.restore_from_D1 is not None:
        model_D1.load_state_dict(torch.load(args.restore_from_D2))
    #model_D1.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D1.pth'))	
    model_D1.train()
    model_D1.cuda()	    
    
    # init D2	
    model_D2 = s4GAN_feature_discriminator(layer_name=args.layer_name)
    if args.restore_from_D2 is not None:
        model_D2.load_state_dict(torch.load(args.restore_from_D2))
    #model_D2.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D2.pth'))	
    model_D2.train()
    model_D2.cuda()	
	
	################################################################
	
    # init D31	
    model_D31 = Split_feature_discriminator_0(layer_name='layer3')
    if args.restore_from_D31 is not None:
        model_D31.load_state_dict(torch.load(args.restore_from_D31))
    #model_D31.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D31.pth'))	
    model_D31.train()
    model_D31.cuda()	
	
    # init D32	
    model_D32 = Split_feature_discriminator_0(layer_name='layer3')
    if args.restore_from_D32 is not None:
        model_D32.load_state_dict(torch.load(args.restore_from_D32))
    #model_D32.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D32.pth'))	
    model_D32.train()
    model_D32.cuda()	
	
    # init D33	
    model_D33 = Split_feature_discriminator_0(layer_name='layer3')
    if args.restore_from_D33 is not None:
        model_D33.load_state_dict(torch.load(args.restore_from_D33))
    #model_D33.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D33.pth'))	
    model_D33.train()
    model_D33.cuda()	
	
    # init D34	
    model_D34 = Split_feature_discriminator_0(layer_name='layer3')
    if args.restore_from_D34 is not None:
        model_D34.load_state_dict(torch.load(args.restore_from_D34))
    #model_D34.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D34.pth'))	
    model_D34.train()
    model_D34.cuda()	
	#####################################################################
    # init D41	
    model_D41 = Split_feature_discriminator_0(layer_name='layer4')
    if args.restore_from_D41 is not None:
        model_D41.load_state_dict(torch.load(args.restore_from_D41))
    #model_D41.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D41.pth'))	
    model_D41.train()
    model_D41.cuda()	
	
    # init D42	
    model_D42 = Split_feature_discriminator_0(layer_name='layer4')
    if args.restore_from_D42 is not None:
        model_D42.load_state_dict(torch.load(args.restore_from_D42))
    #model_D42.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D42.pth'))	
    model_D42.train()
    model_D42.cuda()	
	
    # init D43	
    model_D43 = Split_feature_discriminator_0(layer_name='layer4')
    if args.restore_from_D43 is not None:
        model_D43.load_state_dict(torch.load(args.restore_from_D43))
    #model_D43.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D43.pth'))	
    model_D43.train()
    model_D43.cuda()	
	
    # init D44	
    model_D44 = Split_feature_discriminator_0(layer_name='layer4')
    if args.restore_from_D44 is not None:
        model_D44.load_state_dict(torch.load(args.restore_from_D44))
    #model_D44.load_state_dict(torch.load('./checkpoints_advent_feature/voc_advent_feature_landsat_layer3/VOC_60000_D44.pth'))	
    model_D44.train()
    model_D44.cuda()		
	
	
	
	
    if not os.path.exists(args.checkpoint_dir):
        os.makedirs(args.checkpoint_dir)
		
    # load data and do preprocessing,such as rescale,flip
	
    train_dataset = VOCDataSet(args.land_data_dir, args.data_list, crop_size=input_size,
                        scale=args.random_scale, mirror=args.random_mirror, mean=IMG_MEAN2)  # landsat-8 data , labeled
    train_remain_dataset = VOCDataSet_unlabel(args.gf_data_dir, args.data_list3, crop_size=input_size,
                        scale=args.random_scale, mirror=args.random_mirror, mean=IMG_MEAN)  # zy3 data for training ,unlabeled	
						
    train_dataset_size = len(train_dataset)
    print ('dataset size: ', train_dataset_size)
	
	
    trainloader = data.DataLoader(train_dataset,
                        batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=True)
    trainloader_remain = data.DataLoader(train_remain_dataset,
                        batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=True)
						
    trainloader_remain_iter = iter(trainloader_remain)	
    trainloader_iter = iter(trainloader)

    # optimizer for segmentation network
    optimizer = optim.SGD(model.optim_parameters(args),
                lr=args.learning_rate, momentum=args.momentum,weight_decay=args.weight_decay)
    optimizer.zero_grad()

    # optimizer for discriminator network
    # optimizer_D = optim.Adam(model_D.parameters(), lr=args.learning_rate_D, betas=(0.9,0.99))
    # optimizer_D.zero_grad()
	
    optimizer_D1 = optim.Adam(model_D1.parameters(), lr=args.learning_rate_D, betas=(0.9,0.99))
    optimizer_D1.zero_grad()	
    
    # optimizer_D2 = optim.Adam(model_D2.parameters(), lr=1*args.learning_rate_D, betas=(0.9,0.99))
    # optimizer_D2.zero_grad()	
	

    optimizer_D31 = optim.Adam(model_D31.parameters(), lr=1*args.learning_rate_D, betas=(0.9,0.99))
    optimizer_D31.zero_grad()		
    optimizer_D32 = optim.Adam(model_D32.parameters(), lr=1*args.learning_rate_D, betas=(0.9,0.99))
    optimizer_D32.zero_grad()	
    optimizer_D33 = optim.Adam(model_D33.parameters(), lr=1*args.learning_rate_D, betas=(0.9,0.99))
    optimizer_D33.zero_grad()		
    optimizer_D34 = optim.Adam(model_D34.parameters(), lr=1*args.learning_rate_D, betas=(0.9,0.99))
    optimizer_D34.zero_grad()	

    optimizer_D41 = optim.Adam(model_D41.parameters(), lr=1*args.learning_rate_D, betas=(0.9,0.99))
    optimizer_D41.zero_grad()		
    optimizer_D42 = optim.Adam(model_D42.parameters(), lr=1*args.learning_rate_D, betas=(0.9,0.99))
    optimizer_D42.zero_grad()	
    optimizer_D43 = optim.Adam(model_D43.parameters(), lr=1*args.learning_rate_D, betas=(0.9,0.99))
    optimizer_D43.zero_grad()		
    optimizer_D44 = optim.Adam(model_D44.parameters(), lr=1*args.learning_rate_D, betas=(0.9,0.99))
    optimizer_D44.zero_grad()	
	
	
    interp = nn.Upsample(size=(input_size[0], input_size[1]), mode='bilinear', align_corners=True)

    # labels for adversarial training
    pred_label = 0
    gt_label = 1

    #y_real_, y_fake_ = Variable(torch.ones(args.batch_size, 1).cuda(args.gpu)), Variable(torch.zeros(args.batch_size, 1).cuda(args.gpu))
    y_real_, y_fake_ = Variable(torch.ones(args.batch_size, 1).cuda()), Variable(torch.zeros(args.batch_size, 1).cuda())

    source_label = 0
    target_label = 1

    for i_iter in  range(args.num_steps+1):
    #for i_iter in  range(60001, args.num_steps+1):
        loss_ce_value = 0
        loss_D_value = 0
        loss_D2_value = 0	
		
        loss_D31_value = 0	
        loss_D32_value = 0	
        loss_D33_value = 0	
        loss_D34_value = 0
		
        loss_D41_value = 0	
        loss_D42_value = 0	
        loss_D43_value = 0	
        loss_D44_value = 0		
	
        loss_fm_value = 0
        loss_S_value = 0
        loss_adv_trg_value =0
        loss_D1_value = 0
        loss_adapt_value = 0
        loss_st_value = 0
        optimizer.zero_grad()
        adjust_learning_rate(optimizer, i_iter)
        
        # optimizer_D.zero_grad()
        # adjust_learning_rate_D(optimizer_D, i_iter)
        
        optimizer_D1.zero_grad()
        adjust_learning_rate_D(optimizer_D1, i_iter)
		
        # optimizer_D2.zero_grad()
        # adjust_learning_rate_D(optimizer_D2, i_iter)

        optimizer_D31.zero_grad()
        adjust_learning_rate_D(optimizer_D31, i_iter)
        optimizer_D32.zero_grad()
        adjust_learning_rate_D(optimizer_D32, i_iter)
        optimizer_D33.zero_grad()
        adjust_learning_rate_D(optimizer_D33, i_iter)
        optimizer_D34.zero_grad()
        adjust_learning_rate_D(optimizer_D34, i_iter)	
		
        optimizer_D41.zero_grad()
        adjust_learning_rate_D(optimizer_D41, i_iter)
        optimizer_D42.zero_grad()
        adjust_learning_rate_D(optimizer_D42, i_iter)
        optimizer_D43.zero_grad()
        adjust_learning_rate_D(optimizer_D43, i_iter)
        optimizer_D44.zero_grad()
        adjust_learning_rate_D(optimizer_D44, i_iter)			
		
		
        # train Segmentation Network 
        # don't accumulate grads in D
        # for param in model_D.parameters():
            # param.requires_grad = False
			
        for param in model_D1.parameters():
            param.requires_grad = False

        # for param in model_D2.parameters():
            # param.requires_grad = False
			
        for param in model_D31.parameters():
            param.requires_grad = False			
        for param in model_D32.parameters():
            param.requires_grad = False
        for param in model_D33.parameters():
            param.requires_grad = False				
        for param in model_D34.parameters():
            param.requires_grad = False		
			
        for param in model_D41.parameters():
            param.requires_grad = False			
        for param in model_D42.parameters():
            param.requires_grad = False
        for param in model_D43.parameters():
            param.requires_grad = False				
        for param in model_D44.parameters():
            param.requires_grad = False					
			
			
        ########################## 1. training loss for labeled data only  #############################
        try:
            batch = next(trainloader_iter)
        except:
            trainloader_iter = iter(trainloader)
            batch = next(trainloader_iter)

        images, labels, _, _, _ = batch
        images = Variable(images).cuda()
        feature_img3, feature_img4, pred = model(images)
		
        pred = interp(pred)		
		
		# Cross entropy loss 
        loss_ce = loss_calc(pred, labels) # Cross entropy loss for labeled data
		
		# split convoluation3
        y3 = torch.chunk(feature_img3,4,dim=1)
        y31 = y3[0]
        y32 = y3[1]
        y33 = y3[2]	
        y34 = y3[3]			
		
        D31_out_z, D31_out_y_pred = model_D31(y31) 	
        D32_out_z, D32_out_y_pred = model_D32(y32) 
        D33_out_z, D33_out_y_pred = model_D33(y33) 
        D34_out_z, D34_out_y_pred = model_D34(y34)    
		
		# split convoluation4
        y4 = torch.chunk(feature_img4,4,dim=1)
        y41 = y4[0]
        y42 = y4[1]
        y43 = y4[2]	
        y44 = y4[3]			
		
        D41_out_z, D41_out_y_pred = model_D41(y41) 	
        D42_out_z, D42_out_y_pred = model_D42(y42) 
        D43_out_z, D43_out_y_pred = model_D43(y43) 
        D44_out_z, D44_out_y_pred = model_D44(y44)    		
		
        
        ############################ 2. training loss for remaining unlabeled data  ####################
        try:
            batch_remain = next(trainloader_remain_iter)
        except:
            trainloader_remain_iter = iter(trainloader_remain)
            batch_remain = next(trainloader_remain_iter)
        
        images_remain, _, _, _ = batch_remain
        #images_remain = Variable(images_remain).cuda(args.gpu)
        images_remain = Variable(images_remain).cuda()	
        feature_remain_img3, feature_remain_img4, pred_remain = model(images_remain)
        pred_remain = interp(pred_remain)
        
        # entropy maps loss
        d1_out_remain = model_D1(prob_2_entropy(F.softmax(pred_remain, dim=1)))
        loss_adv_trg_remain = bce_loss(d1_out_remain, source_label)       # source_label = 0    #target_label = 1     
		
		# split convoluation
        z3 = torch.chunk(feature_remain_img3,4,dim=1)
        z31 = z3[0]
        z32 = z3[1]
        z33 = z3[2]	
        z34 = z3[3]	
        
		# adapt loss		
        D31_out_z_remain, D31_out_y_pred_remain = model_D31(z31) 
        D32_out_z_remain, D32_out_y_pred_remain = model_D32(z32) 
        D33_out_z_remain, D33_out_y_pred_remain = model_D33(z33) 		
        D34_out_z_remain, D34_out_y_pred_remain = model_D34(z34) 
		
		# split convoluation
        z4 = torch.chunk(feature_remain_img4,4,dim=1)
        z41 = z4[0]
        z42 = z4[1]
        z43 = z4[2]	
        z44 = z4[3]	
        
		# adapt loss		
        D41_out_z_remain, D41_out_y_pred_remain = model_D41(z41) 
        D42_out_z_remain, D42_out_y_pred_remain = model_D42(z42) 
        D43_out_z_remain, D43_out_y_pred_remain = model_D43(z43) 		
        D44_out_z_remain, D44_out_y_pred_remain = model_D44(z44) 		
		
		
        loss_adapt31 = torch.mean(torch.abs(torch.mean(D31_out_y_pred, 0) - torch.mean(D31_out_y_pred_remain, 0)))
        loss_adapt32 = torch.mean(torch.abs(torch.mean(D32_out_y_pred, 0) - torch.mean(D32_out_y_pred_remain, 0)))
        loss_adapt33 = torch.mean(torch.abs(torch.mean(D33_out_y_pred, 0) - torch.mean(D33_out_y_pred_remain, 0)))
        loss_adapt34 = torch.mean(torch.abs(torch.mean(D34_out_y_pred, 0) - torch.mean(D34_out_y_pred_remain, 0)))
        loss_adapt3 =  loss_adapt31 + loss_adapt32 + loss_adapt33 + loss_adapt34  
		
		
        loss_adapt41 = torch.mean(torch.abs(torch.mean(D41_out_y_pred, 0) - torch.mean(D41_out_y_pred_remain, 0)))
        loss_adapt42 = torch.mean(torch.abs(torch.mean(D42_out_y_pred, 0) - torch.mean(D42_out_y_pred_remain, 0)))
        loss_adapt43 = torch.mean(torch.abs(torch.mean(D43_out_y_pred, 0) - torch.mean(D43_out_y_pred_remain, 0)))
        loss_adapt44 = torch.mean(torch.abs(torch.mean(D44_out_y_pred, 0) - torch.mean(D44_out_y_pred_remain, 0)))
        loss_adapt4 =  loss_adapt41 + loss_adapt42 + loss_adapt43 + loss_adapt44  		
		
		
		
		# total loss
        loss_S = args.lambda_adapt*(loss_adapt3+loss_adapt4) + args.lambda_ce*loss_ce  +  args.lambda_entropy*loss_adv_trg_remain
        loss_S.backward()
		
		# each loss value
        loss_adv_trg_value += args.lambda_entropy*loss_adv_trg_remain.item()
        loss_ce_value += args.lambda_ce*loss_ce.item()
        loss_adapt_value += args.lambda_adapt*(loss_adapt3+loss_adapt4).item()		
        loss_S_value += loss_S.item()
		        
        
        ###################################################### 5.train D1  #################################################
        for param in model_D1.parameters():
            param.requires_grad = True

        # train with source

        pred_src_main = pred.detach()
        d_out_main = model_D1(prob_2_entropy(F.softmax(pred_src_main, dim=1)))
        loss_source_main = bce_loss(d_out_main, source_label)

        # train with target
        pred_trg_main = pred_remain.detach()
        d_out_main = model_D1(prob_2_entropy(F.softmax(pred_trg_main, dim=1)))
        loss_target_main = bce_loss(d_out_main, target_label)     # source_label = 0    target_label = 1


        loss_entropy = loss_source_main/2 + loss_target_main/ 2
        loss_entropy.backward()
        loss_D1_value += loss_entropy.item()		        
		
		
        ###################################################### 6.train D31  #################################################
        for param in model_D31.parameters():
            param.requires_grad = True

        # train with pred
        feature_remain_img = y31.detach()  # detach does not allow the graddients to back propagate.
        
        D31_out_z3_remain, _ = model_D31(feature_remain_img) 	
        #y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
        y3_fake_ = Variable(torch.zeros(D31_out_z3_remain.size(0), 1).cuda())		
        loss_D31_fake = criterion(D31_out_z3_remain, y3_fake_) 

        # train with gt
        feature_img = z31.detach()		
        D31_out_z3, _ = model_D31(feature_img)
        #y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu)) 
        y3_real_ = Variable(torch.ones(D31_out_z3.size(0), 1).cuda()) 		
        loss_D31_real = criterion(D31_out_z3, y3_real_)
        
        loss_D31 = (loss_D31_fake + loss_D31_real)/2.0
        loss_D31.backward()
        loss_D31_value += loss_D31.item()		
		
        ###################################################### 6.train D32  #################################################
        for param in model_D32.parameters():
            param.requires_grad = True

        # train with pred
        feature_remain_img = y32.detach()  # detach does not allow the graddients to back propagate.
        
        D32_out_z3_remain, _ = model_D32(feature_remain_img) 	
        #y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
        y3_fake_ = Variable(torch.zeros(D32_out_z3_remain.size(0), 1).cuda())		
        loss_D32_fake = criterion(D32_out_z3_remain, y3_fake_) 

        # train with gt
        feature_img = z32.detach()		
        D32_out_z3, _ = model_D32(feature_img)
        #y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu)) 
        y3_real_ = Variable(torch.ones(D32_out_z3.size(0), 1).cuda()) 		
        loss_D32_real = criterion(D32_out_z3, y3_real_)
        
        loss_D32 = (loss_D32_fake + loss_D32_real)/2.0
        loss_D32.backward()
        loss_D32_value += loss_D32.item()		

        ###################################################### 6.train D33  #################################################
        for param in model_D33.parameters():
            param.requires_grad = True

        # train with pred
        feature_remain_img = y33.detach()  # detach does not allow the graddients to back propagate.
        
        D33_out_z3_remain, _ = model_D33(feature_remain_img) 	
        #y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
        y3_fake_ = Variable(torch.zeros(D33_out_z3_remain.size(0), 1).cuda())		
        loss_D33_fake = criterion(D33_out_z3_remain, y3_fake_) 

        # train with gt
        feature_img = z33.detach()		
        D33_out_z3, _ = model_D33(feature_img)
        #y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu)) 
        y3_real_ = Variable(torch.ones(D33_out_z3.size(0), 1).cuda()) 		
        loss_D33_real = criterion(D33_out_z3, y3_real_)
        
        loss_D33 = (loss_D33_fake + loss_D33_real)/2.0
        loss_D33.backward()
        loss_D33_value += loss_D33.item()				
        ###################################################### 6.train D34  #################################################
        for param in model_D34.parameters():
            param.requires_grad = True

        # train with pred
        feature_remain_img = y34.detach()  # detach does not allow the graddients to back propagate.
        
        D34_out_z3_remain, _ = model_D34(feature_remain_img) 	
        #y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
        y3_fake_ = Variable(torch.zeros(D34_out_z3_remain.size(0), 1).cuda())		
        loss_D34_fake = criterion(D34_out_z3_remain, y3_fake_) 

        # train with gt
        feature_img = z34.detach()		
        D34_out_z3, _ = model_D34(feature_img)
        #y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu)) 
        y3_real_ = Variable(torch.ones(D34_out_z3.size(0), 1).cuda()) 		
        loss_D34_real = criterion(D34_out_z3, y3_real_)
        
        loss_D34 = (loss_D34_fake + loss_D34_real)/2.0
        loss_D34.backward()
        loss_D34_value += loss_D34.item()		
		
        ###################################################### 6.train D41  #################################################
        for param in model_D41.parameters():
            param.requires_grad = True

        # train with pred
        feature_remain_img = y41.detach()  # detach does not allow the graddients to back propagate.
        
        D41_out_z4_remain, _ = model_D41(feature_remain_img) 	
        #y4_fake_ = Variable(torch.zeros(D_out_z4.size(0), 1).cuda(args.gpu))
        y4_fake_ = Variable(torch.zeros(D41_out_z4_remain.size(0), 1).cuda())		
        loss_D41_fake = criterion(D41_out_z4_remain, y4_fake_) 

        # train with gt
        feature_img = z41.detach()		
        D41_out_z4, _ = model_D41(feature_img)
        #y4_real_ = Variable(torch.ones(D_out_z4_gt.size(0), 1).cuda(args.gpu)) 
        y4_real_ = Variable(torch.ones(D41_out_z4.size(0), 1).cuda()) 		
        loss_D41_real = criterion(D41_out_z4, y4_real_)
        
        loss_D41 = (loss_D41_fake + loss_D41_real)/2.0
        loss_D41.backward()
        loss_D41_value += loss_D41.item()		
		
        ###################################################### 6.train D42  #################################################
        for param in model_D42.parameters():
            param.requires_grad = True

        # train with pred
        feature_remain_img = y42.detach()  # detach does not allow the graddients to back propagate.
        
        D42_out_z4_remain, _ = model_D42(feature_remain_img) 	
        #y4_fake_ = Variable(torch.zeros(D_out_z4.size(0), 1).cuda(args.gpu))
        y4_fake_ = Variable(torch.zeros(D42_out_z4_remain.size(0), 1).cuda())		
        loss_D42_fake = criterion(D42_out_z4_remain, y4_fake_) 

        # train with gt
        feature_img = z42.detach()		
        D42_out_z4, _ = model_D42(feature_img)
        #y4_real_ = Variable(torch.ones(D_out_z4_gt.size(0), 1).cuda(args.gpu)) 
        y4_real_ = Variable(torch.ones(D42_out_z4.size(0), 1).cuda()) 		
        loss_D42_real = criterion(D42_out_z4, y4_real_)
        
        loss_D42 = (loss_D42_fake + loss_D42_real)/2.0
        loss_D42.backward()
        loss_D42_value += loss_D42.item()		

        ###################################################### 6.train D43  #################################################
        for param in model_D43.parameters():
            param.requires_grad = True

        # train with pred
        feature_remain_img = y43.detach()  # detach does not allow the graddients to back propagate.
        
        D43_out_z4_remain, _ = model_D43(feature_remain_img) 	
        #y4_fake_ = Variable(torch.zeros(D_out_z4.size(0), 1).cuda(args.gpu))
        y4_fake_ = Variable(torch.zeros(D43_out_z4_remain.size(0), 1).cuda())		
        loss_D43_fake = criterion(D43_out_z4_remain, y4_fake_) 

        # train with gt
        feature_img = z43.detach()		
        D43_out_z4, _ = model_D43(feature_img)
        #y4_real_ = Variable(torch.ones(D_out_z4_gt.size(0), 1).cuda(args.gpu)) 
        y4_real_ = Variable(torch.ones(D43_out_z4.size(0), 1).cuda()) 		
        loss_D43_real = criterion(D43_out_z4, y4_real_)
        
        loss_D43 = (loss_D43_fake + loss_D43_real)/2.0
        loss_D43.backward()
        loss_D43_value += loss_D43.item()				
        ###################################################### 6.train D44  #################################################
        for param in model_D44.parameters():
            param.requires_grad = True

        # train with pred
        feature_remain_img = y44.detach()  # detach does not allow the graddients to back propagate.
        
        D44_out_z4_remain, _ = model_D44(feature_remain_img) 	
        #y4_fake_ = Variable(torch.zeros(D_out_z4.size(0), 1).cuda(args.gpu))
        y4_fake_ = Variable(torch.zeros(D44_out_z4_remain.size(0), 1).cuda())		
        loss_D44_fake = criterion(D44_out_z4_remain, y4_fake_) 

        # train with gt
        feature_img = z44.detach()		
        D44_out_z4, _ = model_D44(feature_img)
        #y4_real_ = Variable(torch.ones(D_out_z4_gt.size(0), 1).cuda(args.gpu)) 
        y4_real_ = Variable(torch.ones(D44_out_z4.size(0), 1).cuda()) 		
        loss_D44_real = criterion(D44_out_z4, y4_real_)
        
        loss_D44 = (loss_D44_fake + loss_D44_real)/2.0
        loss_D44.backward()
        loss_D44_value += loss_D44.item()		
				
		
        optimizer.step()
        # optimizer_D.step()
        optimizer_D1.step()		
        optimizer_D31.step()			
        optimizer_D32.step()
        optimizer_D33.step()			
        optimizer_D34.step()

        optimizer_D41.step()			
        optimizer_D42.step()
        optimizer_D43.step()			
        optimizer_D44.step()	
				
		
        if i_iter %20 ==0:
            print('iter={0:5d},loss_ce={1:.3f},l_ada={2:.3f},l_S={3:.3f},l_D1={4:.3f},l_adv_trg={5:.3f}'.format(i_iter, loss_ce_value, loss_adapt_value, loss_S_value, loss_D1_value, loss_adv_trg_value))
			
            print('l_D31={0:.3f},l_D32={1:.3f},l_D33={2:.3f},l_D34={3:.3f},l_D41={4:.3f},l_D42={5:.3f},l_D43={6:.3f},l_D44={7:.3f}'.format( loss_D31_value, loss_D32_value, loss_D33_value, loss_D34_value, loss_D41_value, loss_D42_value, loss_D43_value, loss_D44_value))			
			

        if i_iter >= args.num_steps-1:
            print ('save model ...')
            torch.save(model.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'.pth'))
            torch.save(model_D1.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D1.pth'))			
            torch.save(model_D31.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D31.pth'))
            torch.save(model_D32.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D32.pth'))	            
            torch.save(model_D33.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D33.pth'))		
            torch.save(model_D34.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D34.pth'))		
            torch.save(model_D41.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D41.pth'))
            torch.save(model_D42.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D42.pth'))	            
            torch.save(model_D43.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D43.pth'))		
            torch.save(model_D44.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D44.pth'))		
			
            break

        if i_iter % args.save_pred_every == 0 and i_iter!=0:
            print ('saving checkpoint  ...')
            torch.save(model.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'.pth'))
            torch.save(model_D1.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D1.pth'))			
            torch.save(model_D31.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D31.pth'))
            torch.save(model_D32.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D32.pth'))	            
            torch.save(model_D33.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D33.pth'))		
            torch.save(model_D34.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D34.pth'))		
            torch.save(model_D41.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D41.pth'))
            torch.save(model_D42.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D42.pth'))	            
            torch.save(model_D43.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D43.pth'))		
            torch.save(model_D44.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D44.pth'))			
    end = timeit.default_timer()
    print (end-start,'seconds')

if __name__ == '__main__':
    main()
